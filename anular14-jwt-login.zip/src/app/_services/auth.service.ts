import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { StorageService } from '../_services/storage.service';
import { Router } from '@angular/router';


const AUTH_API = 'http://localhost:8080/';
import { environment } from '../../environments/environment';

const httpOptions = {
  headers: new HttpHeaders({ 'Content-Type': 'application/json' })
};

@Injectable({
  providedIn: 'root',
})
export class AuthService {
  router: any;
  constructor(private http: HttpClient,private storageService: StorageService) {}

  login(username: string, password: string) {
    localStorage.removeItem('user');
    this.storageService.userSubject.next(null);
return this.http.post<any>(
      AUTH_API + 'api/auth/signin',
      {
        username,
        password,
      },
      httpOptions
    );
  }

  register(username: string, email: string, password: string): Observable<any> {
    return this.http.post(
      AUTH_API + 'signup',
      {
        username,
        email,
        password,
      },
      httpOptions
    );
  }

  logout() {
    localStorage.removeItem('user');
    this.storageService.userSubject.next(null);
    window.location.reload();
  }

}