export class User {
    id?: number;
    username?: string;
    token?: string;
}